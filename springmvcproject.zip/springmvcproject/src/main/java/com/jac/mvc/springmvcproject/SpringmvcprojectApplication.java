package com.jac.mvc.springmvcproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringmvcprojectApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringmvcprojectApplication.class, args);
	}

}
