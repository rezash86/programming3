package com.jac.mvc.springmvcproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringmvcprojectApplicationTests {

	@Test
	void contextLoads() {
	}

}
